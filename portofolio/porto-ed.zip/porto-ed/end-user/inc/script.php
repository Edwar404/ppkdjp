<script src="content/assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="content/assets/js/Lightbox-Gallery-baguetteBox.min.js"></script>
    <script src="content/assets/js/Lightbox-Gallery.js"></script>
    <script src="content/assets/js/responsive-blog-card-slider-01-swiper-bundle.min.js"></script>
    <script src="content/assets/js/responsive-blog-card-slider-02-responsive-blog-card-slider.js"></script>
    <script src="content/assets/js/Skill-Item-skill.js"></script>
    <script src="content/assets/js/Skill-Item-wow.js"></script>