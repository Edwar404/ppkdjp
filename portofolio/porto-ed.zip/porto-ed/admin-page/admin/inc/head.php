<!-- plugins:css -->
<link
        rel="stylesheet"
        href="../assets/template/assets/vendors/mdi/css/materialdesignicons.min.css" />
    <link
        rel="stylesheet"
        href="../assets/template/assets/vendors/css/vendor.bundle.base.css" />
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link
        rel="stylesheet"
        href="../assets/template/assets/vendors/jvectormap/jquery-jvectormap.css" />
    <link
        rel="stylesheet"
        href="../assets/template/assets/vendors/flag-icon-css/css/flag-icon.min.css" />
    <link
        rel="stylesheet"
        href="../assets/template/assets/vendors/owl-carousel-2/owl.carousel.min.css" />
    <link
        rel="stylesheet"
        href="../assets/template/assets/vendors/owl-carousel-2/owl.theme.default.min.css" />
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/template/assets/css/style.css" />
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/template/assets/images/favicon.png" />