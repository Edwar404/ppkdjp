<div class="container pembungkus">
        <div class="row d-flex justify-content-center align-items-center">
            <div class="col text-center">
                <img src="assets/logo.jpeg" alt="Logo PPKD JakPus" class='img-fluid'>
            </div>
            <div class="col d-flex justify-content-center align-items-center parag">
                <p><q>
                        Jadilah penjaga pintu menuju petualangan tak terbatas,
                        karena setiap kata yang diatur adalah kunci menuju cakrawala pengetahuan yang lebih luas.
                </q></p>
            </div>
        </div>
</div>