    <nav class="navbar navbar-expand-lg mb-5">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active me-3" aria-current="page" href="index.php">Dashboard</a>
            <a class="nav-link me-3" href="?pg=table-anggota">Manage Accounts</a>
            <a class="nav-link me-3" href="?pg=table-buku">Manage Books</a>
          </div>
        </div>
      </div>
    </nav>