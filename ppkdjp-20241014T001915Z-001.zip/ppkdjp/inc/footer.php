<footer class="p-3 text-center mt-5">
    <p>Copyright &copy; 2024 PPKD - Jakarta Pusat</p>
</footer>
